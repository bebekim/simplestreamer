package ssp;

public class SimpleStreamerProtocol {

	public static final int defaultPort = 6262;
	
}
