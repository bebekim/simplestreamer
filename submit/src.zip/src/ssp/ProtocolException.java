package ssp;

public class ProtocolException extends Exception {

	public ProtocolException(String string) {
		super(string);
	}
}
